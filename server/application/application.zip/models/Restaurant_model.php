<?php


class Restaurant_model extends CI_Model
{

    private $table = 'restaurants';

    function __construct()
    {
        /* Call the Model constructor */
        parent::__construct();
    }

    public function getRestaurant($restaurantId)
    {
        return $this->db->get_where($this->table, array('id' => $restaurantId))->first_row();
    }

    public function getRestaurants($categoryId)
    {
        return $this->db->get_where($this->table, array('category_id' => $categoryId))->result();
    }

    public function getRestaurantSearch($categoryId, $keyword, $lat, $lng)
    {
        $where = $categoryId == '' ? '' : ' AND B.category_id = "' . $categoryId . '" ';
        $query = '
            SELECT B.id AS restaurant_id, B.restaurant_name, 
                A.id, A.address, 
                111.1111 * DEGREES(ACOS(COS(RADIANS(lat))* COS(RADIANS(' . $lat . '))* COS(RADIANS(lng - ' . $lng . '))+ SIN(RADIANS(lat))* SIN(RADIANS(' . $lat . ')))) AS distance  
            FROM addresses AS A 
            LEFT OUTER JOIN restaurants AS B ON A.restaurant_id=B.id 
            WHERE CONCAT_WS("", A.address, A.city, B.restaurant_name, B.write_up) LIKE "%' . $keyword . '%" 
                ' . $where . '
            ORDER BY distance 
        ';
        $result = $this->db->query($query);
        return $result->result_array($result);
    }

    public function saveRestaurant($data)
    {

        $rowId = $data['id'];

        $cols = array('category_id', 'restaurant_name', 'write_up');
        $row = array();
        foreach ($cols as $col) {
            $row[$col] = isset($data[$col]) ? $data[$col] : '';
        }

        if ($rowId) {
            $this->db->where('id', $rowId);
            $result = $this->db->update($this->table, $row);
        } else {
            $result = $this->db->insert($this->table, $row);
            $rowId = $this->db->insert_id();
        }

        if (isset($data['image'])) {
            if (strpos($data['image'], 'base64')) {
                list(, $img) = explode(',', $data['image']);
                file_put_contents('uploads/restaurants/' . $rowId . '.jpg', base64_decode($img));
            }
        }

        return $result;
    }

    public function deleteRestaurant($rowId)
    {
        $restaurantsRowsNum = $this->db->get_where('addresses', array('restaurant_id' => $rowId))->num_rows();
        if ($restaurantsRowsNum) {
            exit(json_encode(array('code' => 'addr', 'num' => $restaurantsRowsNum)));
        } else {
            $adsRowsNum = $this->db->get_where('advertisements', array('restaurant_id' => $rowId))->num_rows();
            if ($adsRowsNum) {
                exit(json_encode(array('code' => 'ads', 'num' => $adsRowsNum)));
            } else {
                unlink('uploads/restaurants/' . $rowId . '.jpg');
                return $this->db->delete($this->table, array('id' => $rowId));
            }
        }
    }
}