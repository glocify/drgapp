<?php


class Category_model extends CI_Model {

    private $table = 'categories';

    function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    }

    public function getCategories()
    {
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function saveCategory($data)
    {

        $rowId = $data['id'];

        if ($rowId) {
            $this->db->where('id', $rowId);
            $result = $this->db->update($this->table, array(
                'title'=> isset($data['title']) ? $data['title'] : '',
                'comment'=>isset($data['comment']) ? $data['comment'] : ''
            ));
        } else {
            $result = $this->db->insert($this->table, array(
                'title'=>isset($data['title']) ? $data['title'] : '',
                'comment'=>isset($data['comment']) ? $data['comment'] : ''
            ));
            $rowId = $this->db->insert_id();
        }
        
        if (isset($data['image'])) {
            if (strpos($data['image'], 'base64')) {
                list(, $img) = explode(',', $data['image']);
                file_put_contents('uploads/categories/' . $rowId .'.jpg', base64_decode($img));
            }
        }

        return $result;
    }

    public function deleteCategory($rowId)
    {
        unlink('uploads/categories/' . $rowId .'.jpg');
        return $this->db->delete($this->table, array('id' => $rowId));
    }
}