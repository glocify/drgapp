<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Restaurants extends CI_Controller
{

    public function index()
    {
        exit('restaurants');
    }

    public function getrestaurants()
    {
        $this->load->database();
        $this->load->model('restaurant_model');

        $categoryId = $this->input->get('category');
        $keyword = $this->input->get('q');

        $rows = $this->restaurant_model->getRestaurants($categoryId, $keyword);

        $result = array();
        if (sizeof($rows)) {
            foreach ($rows as $key => $value) {
                $value->image = $this->getImagePath($value->id, 'restaurants');
                $result[$value->id] = $value;
            }
        }
        echo json_encode($result);
        exit;
    }

    public function searchrestaurants()
    {
        $this->load->database();
        $this->load->model('restaurant_model');

        $categoryId = $this->input->get('category');
        $keyword = $this->input->get('q');
        $lat = $this->input->get('lat');
        $lng = $this->input->get('lng');

        $rows = $this->restaurant_model->getRestaurantSearch($categoryId, $keyword, $lat, $lng);

        $result = array();
        if (sizeof($rows)) {
            foreach ($rows as $key => $value) {
//                if ($value['distance'] > 5) continue;
                $value['image'] = $this->getImagePath($value['restaurant_id'], 'restaurants');
                $result[$value['id']] = $value;
            }
        }
        echo json_encode($result);
        exit;
    }

    /*public function getrestaurant()
    {
        $this->load->database();
        $this->load->model('restaurant_model');

        $restaurantId = $this->input->get('restaurant');

        $result = $this->restaurant_model->getRestaurant($restaurantId);
        $result->main_image = $this->getImagePath($restaurantId, 'restaurants');
        $result->logo_image = $this->getImagePath($restaurantId, 'restaurants');
        echo json_encode($result);
        exit;
    }*/

    public function getrestaurantdetail()
    {
        $this->load->database();
        $this->load->model('address_model');

        $addressId = $this->input->get('address');

        $result = $this->address_model->getRestaurantDetail($addressId);

        $result->main_image = $this->getImagePath($result->id, 'ads');
        $result->logo_image = $this->getImagePath($result->restaurant_id, 'restaurants');
        echo json_encode($result);
        exit;
    }

    public function saverestaurant()
    {
        $this->load->database();
        $this->load->model('restaurant_model');
        $data = json_decode(file_get_contents('php://input'), true);
        $this->restaurant_model->saveRestaurant($data);
        exit;
    }

    public function deleterestaurant()
    {
        $data = $this->input->get();

        $this->load->database();
        $this->load->model('restaurant_model');
        $this->restaurant_model->deleteRestaurant($data['id']);
        exit;
    }

    public function search()
    {
        $this->load->database();
        $this->load->model('restaurant_model');

        $keyword = $this->input->get('keyword');
        $categoryId = $this->input->get('category');

        $rows = $this->restaurant_model->searchRestaurants($categoryId, $keyword);

        $result = array();
        if (sizeof($rows)) {
            foreach ($rows as $key => $value) {
                $value->image = $this->getImagePath($value->id, 'restaurants');
                $result[$value->id] = $value;
            }
        }
        echo json_encode($result);
        exit;
    }

    private function getImagePath($id, $folder)
    {
        $image = 'uploads/' . $folder . '/' . $id . '.jpg';
        return file_exists($image) ? base_url() . $image : './assets/images/no.jpg';
    }
}
